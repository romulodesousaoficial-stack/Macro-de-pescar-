package com.minefishing.macro

import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max

/** Simple on-device motion-spike detector for the user-calibrated bobber region. */
class FishDetector {
    private var previous = IntArray(0)
    private var baseline = 0.0
    private var samples = 0
    private var lastTriggerMs = 0L

    fun analyze(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        pixelStride: Int,
        normalizedX: Float,
        normalizedY: Float,
        sensitivity: Int,
        nowMs: Long
    ): Detection {
        if (width <= 0 || height <= 0 || rowStride <= 0 || pixelStride < 4) return Detection(false, 0.0)
        val cx = (normalizedX.coerceIn(0.01f, 0.99f) * width).toInt().coerceIn(0, width - 1)
        val cy = (normalizedY.coerceIn(0.01f, 0.99f) * height).toInt().coerceIn(0, height - 1)
        val radius = max(12, (minOf(width, height) * 0.027f).toInt())
        val step = max(2, radius / 12)
        val coords = ArrayList<IntArray>()
        var y = (cy - radius).coerceAtLeast(0)
        while (y <= (cy + radius).coerceAtMost(height - 1)) {
            var x = (cx - radius).coerceAtLeast(0)
            while (x <= (cx + radius).coerceAtMost(width - 1)) {
                val index = y * rowStride + x * pixelStride
                if (index >= 0 && index + 2 < buffer.limit()) coords.add(intArrayOf(index))
                x += step
            }
            y += step
        }
        if (coords.isEmpty()) return Detection(false, 0.0)
        val current = IntArray(coords.size)
        var motion = 0.0
        val position = buffer.position()
        for (i in coords.indices) {
            val index = coords[i][0]
            val r = buffer.get(index).toInt() and 0xff
            val g = buffer.get(index + 1).toInt() and 0xff
            val b = buffer.get(index + 2).toInt() and 0xff
            val luma = (r * 3 + g * 6 + b) / 10
            current[i] = luma
            if (previous.size == current.size) motion += abs(luma - previous[i])
        }
        buffer.position(position)
        if (previous.size != current.size) {
            previous = current
            baseline = 0.0
            samples = 0
            return Detection(false, 0.0)
        }
        motion /= current.size.toDouble()
        previous = current
        if (samples < 8) {
            baseline = if (samples == 0) motion else baseline * 0.75 + motion * 0.25
            samples++
            return Detection(false, motion)
        }
        val level = sensitivity.coerceIn(1, 10)
        val minSpike = 22.0 - (level * 1.45)
        val requiredRatio = 1.55
        val isSpike = motion >= minSpike && motion > max(3.0, baseline * requiredRatio)
        // Slowly learn the normal movement, but do not let a bite spike immediately raise the baseline.
        if (!isSpike) baseline = baseline * 0.92 + motion * 0.08
        val cooldownPassed = nowMs - lastTriggerMs >= 5500L
        val triggered = isSpike && cooldownPassed
        if (triggered) lastTriggerMs = nowMs
        return Detection(triggered, motion)
    }

    data class Detection(val bite: Boolean, val motionScore: Double)
}
