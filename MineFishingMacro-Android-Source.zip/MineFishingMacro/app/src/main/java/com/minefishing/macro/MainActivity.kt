package com.minefishing.macro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var sensitivityLabel: TextView
    private lateinit var delayLabel: TextView
    private var sensitivity = 6
    private var recastDelay = 650

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(CaptureService.PREFS, Context.MODE_PRIVATE)
        sensitivity = prefs.getInt("sensitivity", 6)
        recastDelay = prefs.getInt("recast_delay", 650)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::statusView.isInitialized) updatePermissionStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(Color.rgb(15, 23, 42))
        }
        val scroll = android.widget.ScrollView(this)
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "🎣 MineFishing Macro"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Minecraft Java 1.21.1 • MJ Launcher • Android"
            textSize = 14f
            setTextColor(Color.rgb(147, 197, 253))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }, matchWrap())

        statusView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(30, 41, 59))
        }
        root.addView(statusView, matchWrap())

        root.addView(actionButton("1. Permitir janela flutuante") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Permissão de sobreposição já concedida.", Toast.LENGTH_SHORT).show()
        })
        root.addView(actionButton("2. Ativar serviço de toques") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(actionButton("3. Iniciar captura e detector") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Primeiro permita a janela flutuante.", Toast.LENGTH_LONG).show()
            } else if (!FishingAccessibilityService.isEnabled(this)) {
                Toast.makeText(this, "Ative o serviço de toques nas configurações de Acessibilidade.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        })
        root.addView(actionButton("Parar detector") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        })

        sensitivityLabel = label("Sensibilidade da fisgada: $sensitivity/10")
        root.addView(sensitivityLabel, matchWrap())
        root.addView(SeekBar(this).apply {
            max = 9
            progress = (sensitivity - 1).coerceIn(0, 9)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    sensitivity = progress + 1
                    sensitivityLabel.text = "Sensibilidade da fisgada: $sensitivity/10"
                    saveSettings()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, matchWrap())

        delayLabel = label("Espera para lançar de novo: ${recastDelay} ms")
        root.addView(delayLabel, matchWrap())
        root.addView(SeekBar(this).apply {
            max = 1300
            progress = (recastDelay - 200).coerceIn(0, 1300)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    recastDelay = 200 + progress
                    delayLabel.text = "Espera para lançar de novo: ${recastDelay} ms"
                    saveSettings()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "Como usar:\n• Abra o Minecraft e deixe a boia visível.\n• Conceda as permissões acima e inicie a captura.\n• Na janela flutuante, marque a boia e o botão de usar item do MJ Launcher.\n• Ative a automação só depois de calibrar.\n\nO detector usa mudanças de pixels na região marcada; água animada, shaders, partículas e lag podem gerar falsos positivos. Teste primeiro em um mundo privado. Verifique as regras do Redestars antes de usar macros."
            textSize = 14f
            setTextColor(Color.rgb(203, 213, 225))
            setPadding(0, dp(18), 0, dp(12))
        }, matchWrap())
        setContentView(scroll)
        updatePermissionStatus()
    }

    @Deprecated("Legacy callback is used here for broad Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            saveSettings()
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
            Toast.makeText(this, "Captura iniciada. Volte ao jogo e calibre os alvos.", Toast.LENGTH_LONG).show()
        } else if (requestCode == REQUEST_CAPTURE) {
            Toast.makeText(this, "A captura de tela não foi autorizada.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePermissionStatus() {
        val overlayOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
        val accessibilityOk = FishingAccessibilityService.isEnabled(this)
        statusView.text = "Permissões\nJanela flutuante: ${if (overlayOk) "OK" else "pendente"}\nServiço de toques: ${if (accessibilityOk) "OK" else "pendente"}\nCaptura: será solicitada ao iniciar"
    }

    private fun saveSettings() {
        getSharedPreferences(CaptureService.PREFS, Context.MODE_PRIVATE).edit()
            .putInt("sensitivity", sensitivity)
            .putInt("recast_delay", recastDelay)
            .apply()
    }

    private fun actionButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        layoutParams = lp
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.WHITE)
        setPadding(0, dp(15), 0, 0)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_CAPTURE = 7314 }
}
