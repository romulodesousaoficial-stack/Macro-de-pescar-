package com.minefishing.macro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import kotlin.math.max

class CaptureService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: LinearLayout? = null
    private var statusText: TextView? = null
    private var marker: TextView? = null
    private var markerParams: WindowManager.LayoutParams? = null
    private var calibrating: String? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val detector = FishDetector()
    private var autoRunning = false
    private var biteCount = 0
    private var screenWidth = 1
    private var screenHeight = 1
    private var lastAnalyzeMs = 0L
    private var stopped = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (projection == null) {
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                       else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
            if (resultCode == 0 || data == null) {
                updateStatus("Não recebi a autorização de captura. Pare e inicie novamente pelo app.")
                stopSelf()
                return START_NOT_STICKY
            }
            try {
                beginCapture(resultCode, data)
                showPanel()
            } catch (e: Exception) {
                updateStatus("Falha ao iniciar captura: ${e.javaClass.simpleName}. Tente novamente.")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val channelId = "minefishing_capture"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "MineFishing Macro", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 921, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("MineFishing Macro ativo")
                .setContentText("Detector de boia em execução. Use PARAR para encerrar.")
                .addAction(Notification.Action.Builder(null, "PARAR", stopPending).build())
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("MineFishing Macro ativo")
                .setContentText("Detector de boia em execução.")
                .setOngoing(true).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIFICATION_ID, notification)
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = max(1, metrics.widthPixels)
        screenHeight = max(1, metrics.heightPixels)
        val density = metrics.densityDpi

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        val thread = HandlerThread("MineFishingCapture").apply { start() }
        worker = thread
        workerHandler = Handler(thread.looper)
        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ source ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastAnalyzeMs < 120) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastAnalyzeMs = now
            var image: Image? = null
            try {
                image = source.acquireLatestImage()
                if (image != null) analyzeImage(image!!, now)
            } catch (_: Exception) {
                // A frame can be dropped if Android revokes or rotates the capture surface.
            } finally {
                image?.close()
            }
        }, workerHandler)
        val activeProjection = projection ?: error("MediaProjection indisponível")
        // Android 14+ exige um callback registrado antes da criação da VirtualDisplay.
        activeProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)
        virtualDisplay = activeProjection.createVirtualDisplay(
            "MineFishingScreen", screenWidth, screenHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, workerHandler
        )
    }

    private fun analyzeImage(image: Image, nowMs: Long) {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("bobber_set", false)) return
        val plane = image.planes.firstOrNull() ?: return
        val targetX = prefs.getFloat("bobber_x", 0.5f)
        val targetY = prefs.getFloat("bobber_y", 0.54f)
        val result = detector.analyze(
            plane.buffer, image.width, image.height, plane.rowStride, plane.pixelStride,
            targetX, targetY, prefs.getInt("sensitivity", 6), nowMs
        )
        if (result.bite) {
            biteCount++
            runOnMain {
                updateStatus("Possível fisgada detectada ($biteCount). Movimento: ${"%.1f".format(result.motionScore)}")
            }
            if (autoRunning) handleBite()
        }
    }

    private fun handleBite() {
        if (stopped || !autoRunning) return
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("action_set", false)) {
            autoRunning = false
            updateStatus("Marque e salve primeiro o botão de usar item.")
            return
        }
        if (!tapConfiguredAction()) {
            autoRunning = false
            updateStatus("Não consegui enviar o toque. Confira a Acessibilidade.")
            return
        }
        updateStatus("Fisgada: recolhendo a vara…")
        val delay = prefs.getInt("recast_delay", 650).toLong()
        workerHandler?.postDelayed({
            if (!stopped && autoRunning) {
                tapConfiguredAction()
                updateStatus("Vara relançada. Aguardando a próxima fisgada…")
            }
        }, delay)
    }

    private fun tapConfiguredAction(): Boolean {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val x = prefs.getFloat("action_x", 0.85f) * screenWidth
        val y = prefs.getFloat("action_y", 0.85f) * screenHeight
        return FishingAccessibilityService.tapScreen(x, y)
    }

    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xEE0F172A.toInt())
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0xFF60A5FA.toInt())
            }
        }
        val title = TextView(this).apply {
            text = "MineFishing • 1.21.1"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(2), dp(4), dp(5))
        }
        statusText = TextView(this).apply {
            text = "Detector pronto. Marque a boia."
            textSize = 12f
            setTextColor(0xFFBFDBFE.toInt())
            setPadding(dp(4), 0, dp(4), dp(6))
        }
        root.addView(title)
        root.addView(statusText)
        root.addView(buttonRow(
            button("Marcar boia") { beginCalibration("bobber") },
            button("Salvar boia") { saveCalibration("bobber") }
        ))
        root.addView(buttonRow(
            button("Marcar botão") { beginCalibration("action") },
            button("Salvar botão") { saveCalibration("action") }
        ))
        root.addView(buttonRow(
            button(if (autoRunning) "Auto: ON" else "Auto: OFF") { toggleAutomation() },
            button("Fechar") { stopSelf() }
        ))
        val params = WindowManager.LayoutParams(
            dp(285), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(48) }
        panelParams = params
        try {
            windowManager.addView(root, params)
            panel = root
        } catch (_: Exception) {
            updateStatus("Não consegui mostrar a janela flutuante. Confirme a permissão.")
        }
    }

    private fun beginCalibration(which: String) {
        removeMarker()
        calibrating = which
        val label = if (which == "bobber") "⊕ BOIA" else "⊕ TOQUE"
        val view = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(0x663B82F6)
                setStroke(dp(2), 0xFFFDE047.toInt())
                cornerRadius = dp(8).toFloat()
            }
        }
        val params = WindowManager.LayoutParams(
            dp(72), dp(52), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth / 2 - dp(36)).coerceAtLeast(0)
            y = (screenHeight / 2 - dp(26)).coerceAtLeast(0)
        }
        attachDrag(view, params)
        marker = view
        markerParams = params
        try { windowManager.addView(view, params) } catch (_: Exception) {
            marker = null; markerParams = null
            updateStatus("Não consegui criar o marcador. Confira a permissão de sobreposição.")
            return
        }
        updateStatus(if (which == "bobber") "Arraste ⊕ BOIA até o centro da boia; depois toque Salvar boia." else "Arraste ⊕ TOQUE até o botão de usar item do jogo; depois Salvar botão.")
    }

    private fun attachDrag(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    downX = event.rawX; downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + event.rawX - downX).toInt().coerceIn(0, max(0, screenWidth - view.width))
                    params.y = (startY + event.rawY - downY).toInt().coerceIn(0, max(0, screenHeight - view.height))
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }
    }

    private fun saveCalibration(which: String) {
        val active = calibrating
        val view = marker
        val params = markerParams
        if (active != which || view == null || params == null) {
            updateStatus(if (which == "bobber") "Toque Marcar boia e posicione o marcador primeiro." else "Toque Marcar botão e posicione o marcador primeiro.")
            return
        }
        val nx = ((params.x + view.width / 2f) / screenWidth).coerceIn(0f, 1f)
        val ny = ((params.y + view.height / 2f) / screenHeight).coerceIn(0f, 1f)
        val edit = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (which == "bobber") edit.putFloat("bobber_x", nx).putFloat("bobber_y", ny).putBoolean("bobber_set", true)
        else edit.putFloat("action_x", nx).putFloat("action_y", ny).putBoolean("action_set", true)
        edit.apply()
        removeMarker()
        updateStatus(if (which == "bobber") "Boia salva. Agora marque e salve o botão de usar item." else "Botão salvo. Teste um toque manual e depois ative Auto.")
    }

    private fun toggleAutomation() {
        autoRunning = !autoRunning
        refreshAutoButton()
        if (autoRunning) {
            val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!prefs.getBoolean("bobber_set", false) || !prefs.getBoolean("action_set", false)) {
                autoRunning = false
                refreshAutoButton()
                updateStatus("Calibre e salve a boia e o botão antes de ativar Auto.")
                return
            }
            if (!tapConfiguredAction()) {
                autoRunning = false
                refreshAutoButton()
                updateStatus("Toque não enviado. Verifique se a Acessibilidade está ativa.")
                return
            }
            updateStatus("Pesca automática ligada: lançamento inicial enviado.")
        } else updateStatus("Automação pausada. O detector continua observando a boia.")
    }

    private fun refreshAutoButton() {
        val root = panel ?: return
        // Locate the button by its old text, then update its caption.
        for (i in 0 until root.childCount) {
            val row = root.getChildAt(i) as? LinearLayout ?: continue
            for (j in 0 until row.childCount) {
                val child = row.getChildAt(j) as? Button ?: continue
                if (child.text.toString().startsWith("Auto:")) child.text = if (autoRunning) "Auto: ON" else "Auto: OFF"
            }
        }
    }

    private fun removeMarker() {
        marker?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        marker = null
        markerParams = null
        calibrating = null
    }

    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 11f
        minHeight = dp(40)
        setPadding(dp(2), 0, dp(2), 0)
        layoutParams = LinearLayout.LayoutParams(0, dp(43), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        setOnClickListener { click() }
    }

    private fun buttonRow(vararg buttons: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        buttons.forEach { addView(it) }
    }

    private fun updateStatus(text: String) {
        runOnMain {
            statusText?.text = text
        }
    }

    private fun runOnMain(action: () -> Unit) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) action()
        else android.os.Handler(mainLooper).post(action)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopped = true
        autoRunning = false
        removeMarker()
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close(); imageReader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        worker?.quitSafely(); worker = null; workerHandler = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val PREFS = "minefishing_settings"
        const val ACTION_STOP = "com.minefishing.macro.STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val NOTIFICATION_ID = 7315
    }
}
