package com.minefishing.macro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.graphics.Path
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

class FishingAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun tap(x: Float, y: Float, durationMs: Long = 80L): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false
        val path = Path().apply { moveTo(x, y); lineTo(x + 0.5f, y + 0.5f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(40L, 180L))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    companion object {
        @Volatile private var instance: FishingAccessibilityService? = null
        private val gestureBusy = AtomicBoolean(false)

        fun tapScreen(x: Float, y: Float): Boolean {
            val service = instance ?: return false
            if (!gestureBusy.compareAndSet(false, true)) return false
            val accepted = service.tap(x, y)
            // dispatchGesture completion isn't needed for correctness; release quickly so later taps can run.
            android.os.Handler(service.mainLooper).postDelayed({ gestureBusy.set(false) }, 150L)
            if (!accepted) gestureBusy.set(false)
            return accepted
        }

        fun isEnabled(context: Context): Boolean {
            val expected = ComponentName(context, FishingAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabled)
            while (splitter.hasNext()) if (splitter.next().equals(expected, ignoreCase = true)) return true
            return false
        }
    }
}
