# MineFishing Macro — protótipo Android nativo

Projeto Kotlin/Android para investigar detecção visual da boia no Minecraft Java 1.21.1 executado pelo MJ Launcher. Foi preparado pensando em Android 15, mas **ainda não foi compilado ou validado em um Moto G15 real**.

## O que o código implementa

- Interface com permissões de janela flutuante, Acessibilidade e captura de tela.
- Serviço de captura com MediaProjection e notificação persistente.
- Painel flutuante sobre o jogo.
- Marcadores arrastáveis para calibrar o centro da boia e o botão de usar item.
- Detector experimental de picos de movimento de pixels numa pequena região da boia.
- Ação de toque via AccessibilityService; quando Automação é ativada, envia um toque inicial, tenta recolher após um pico visual e tenta lançar novamente após o intervalo configurado.
- Controle de sensibilidade e atraso de relançamento.

## Limitações importantes

- O detector é heurístico: água animada, shaders, partículas, mudança de câmera, resolução, lag e o próprio overlay podem gerar falsos positivos ou falhas. Não é um classificador treinado e não foi calibrado com gravações reais do Redestars.
- A posição do botão de usar item varia conforme o layout de controles do MJ Launcher. Você precisa calibrá-la manualmente. O toque inicial também depende dessa configuração.
- O Android pede autorização para capturar a tela toda vez que uma sessão começa. A captura aparece na notificação e pode aumentar o consumo de bateria/desempenho.
- A execução de gestos depende da permissão de Acessibilidade. O aplicativo não oculta a captura nem tenta contornar as proteções do Android.
- Não há garantia de compatibilidade com servidores. Verifique as regras do Redestars antes de usar macros; servidores podem proibi-las e aplicar punições.
- É um projeto-fonte, **não um APK pronto para instalar**. Este ambiente de trabalho não tem Android SDK nem Gradle instalados; por isso não foi possível compilar nem confirmar que a aplicação inicia no dispositivo.

## Como compilar

### No Android Studio (computador)

1. Abra a pasta `MineFishingMacro` como projeto existente.
2. Use JDK 17 e instale Android SDK Platform 35 e Build Tools 35.
3. Sincronize Gradle e execute `app` em um aparelho Android 8.0+ ou emulador. Se o Android Studio pedir para gerar o Gradle Wrapper, aceite.
4. Para gerar um APK de depuração, execute `assembleDebug` no painel Gradle.

### GitHub Actions

O arquivo `.github/workflows/android.yml` compila o projeto em um runner do GitHub depois que os arquivos forem enviados para um repositório. O APK fica disponível como artefato da execução da Action.

## Teste inicial recomendado

1. Teste em um mundo privado primeiro.
2. Conceda a janela flutuante e ative o serviço de acessibilidade nas Configurações do Android.
3. Inicie a captura, volte ao Minecraft, arraste `⊕ BOIA` até a boia e salve.
4. Arraste `⊕ TOQUE` até o botão que lança/recolhe a vara e salve.
5. Sem automação, observe se aparecem avisos de possível fisgada. Ajuste a sensibilidade.
6. Só depois teste a automação, com a mão pronta para pausá-la.
